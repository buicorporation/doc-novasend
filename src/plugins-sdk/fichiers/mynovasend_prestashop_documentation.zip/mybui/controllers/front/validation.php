<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

//inclure le fichier de l'api de paiement
include dirname(__FILE__).'/../../classes/api-wpaiement.php';

 class MyBuiValidationModuleFrontController extends ModuleFrontController
 {
    public $operateur = [];
    public $get_token = null;
    public function init()
    {
        parent::init();
    }
    public function initContent()
    {
        parent::initContent();

        // Example condition check (replace with actual condition)
        $error_message = null;
        
        //compare code iso du client à ce qui est supporté
        $customer_country = Context::getContext()->country->iso_code;
         switch ($customer_country) {
          case 'CI':
            $this->get_token  = Configuration::get('MY_KEY_CI') ;
            break;
          case 'CM':
            $this->get_token = Configuration::get('MY_KEY_CM');
            break;
          case 'BF':
            $this->get_token = Configuration::get('MY_KEY_BF');
            break;
          case 'SN':
            $this->get_token = Configuration::get('MY_KEY_SN');
              break;
          default:
           $error_message = "Ce pays n'est pas supporté pour le paiement";
            break;
        }

       /*  if($customer_country ==! 'CI' || $customer_country ==! 'CM')
          $error_message = "Ce pays n'est pas supporté pour le paiement"; */

        //On charge l'ensemble des operateurs pour ce token
        if($this->get_token !=null)
        {
          $version='v1.0';
          $wpaiement_cc = new Wpaiement_CC($version);

          $get_service = $wpaiement_cc->getService($this->get_token);
         
          //gestion erreur
          if($get_service['status']==200)
          {
            $this->operateur = $get_service['data'];
          }
          elseif ($get_service['statusCode']==401) {
            $error_message = $get_service['message'];
          }
          else{
            $error_message = "une erreur est survenue lors de la recupération des opérateurs";
          }
        }

           // on charge notre formulaire
           $this->context->smarty->assign(array(
          //on passe les tokens par pays
           /*  'key_ci' => Configuration::get('MY_KEY_CI'),
            'key_cm' => Configuration::get('MY_KEY_CM'), */
            'operateurs' => $this->operateur,
            //on passe le message d'erreur
            'error_message' => $error_message // Pass the error message to Smarty
          ));
       
        $this->setTemplate('module:mybui/views/templates/front/continuer.tpl');
    }
    public function postProcess()
    {
        parent::postProcess();

        //on recupère l'operateur selection afin d'afficher les instructions.
        if (Tools::isSubmit('continuer')) {
          # code...
          // Récupérer la valeur sélectionnée
          $selected_operator = Tools::getValue('operator');
          $customer_country = Context::getContext()->country->iso_code;
          // Rediriger vers la nouvelle page avec le formulaire
          Tools::redirect($this->context->link->getModuleLink('mybui', 'confirmation', array(
            'selected_operator'=> $selected_operator,
            'pays' => $customer_country
          )));
        }
           
    }
 }