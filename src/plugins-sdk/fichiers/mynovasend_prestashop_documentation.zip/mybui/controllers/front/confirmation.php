<?php
/**
 * Copyright since 2007 PrestaShop SA and Contributors
 * PrestaShop is an International Registered Trademark & Property of PrestaShop SA
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * @author    PrestaShop SA <contact@prestashop.com>
 * @copyright Since 2007 PrestaShop SA and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

//inclure le fichier de l'api de paiement
include dirname(__FILE__).'/../../classes/api-wpaiement.php';
class MyBuiConfirmationModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        parent::initContent();
            $selected_operator = Tools::getValue('selected_operator');
            $pays = Tools::getValue('pays');
            //$getToken = Tools::getValue('get_token');
            $error_message = null;
                //On charge l'ensemble des operateurs pour ce token
                $version='v1.0';
                $wpaiement_cc = new Wpaiement_CC($version);
                $getToken = $this->getPays($pays);
                $get_service = $wpaiement_cc->getService($getToken);
                
                //gestion erreur
                if($get_service['status']==200)
                {
                    $operateur = $get_service['data'];
                }
                elseif ($get_service['statusCode']==401) {
                    $error_message = $get_service['message'];
                }
                else{
                    $error_message = "une erreur est survenue lors de la recupération des opérateurs";
                }

            // Récupérer la devise sélectionnée
            $currency = $this->context->currency;
            $currency_code = $currency->iso_code;
            
            //recuperation de la cart
            $cart = $this->context->cart;
            $total = (float)$cart->getOrderTotal(true, Cart::BOTH);
            // Assigner la valeur à Smarty
            $this->context->smarty->assign(array(
                'selected_operator'=> $selected_operator,
                'operateurs' => $operateur,
                'get_token' =>$getToken ,
                'currency_code'=>$currency_code,
                'montant' =>$total,
                //on passe le message d'erreur
                'error_message' => $error_message // Pass the error message to Smarty
                
            ));
          // Charger le template
          $this->setTemplate('module:mybui/views/templates/front/validation.tpl');
    }
        
    public function postProcess()
    {
        parent::postProcess();
                //verification statut wave
                if (Tools::isSubmit('check')) {
                    if ($this->context->cookie->__get('payments_id')) {
                        //recuperation de la cart
                        $cart = $this->context->cart;
                        $payments_id = $this->context->cookie->__get('payments_id');

                        $wpaiement_cc = new Wpaiement_CC($version);
                        $result = $wpaiement_cc->CheckPaymentMobile($payments_id, $_POST['get_token'], 3, 15);
                        //appel fonction mise à jour panier
                        $this->updateStatusCart($result['payments']['status'],$cart->id , $this->context->cookie->__get('total_cart'), $this->module->displayName, $this->context->currency->id);
                        //Destruction cookies avant redirection
                        unset($this->context->cookie->$payments_id);
                        unset($this->context->cookie->$total_cart);
                        Tools::redirect('index.php?controller=history');
                    }
                    else {
                        # code...
                        $this->errors[] = $this->l('Aucun paiement en cours de validation ');
                        $this->redirectWithNotifications($this->getCurrentURL());
                    }
                    
                }
                //traitement de du paiement
                if(Tools::isSubmit('valider'))
                {
                  
                //recuperation de la cart
                $cart = $this->context->cart;
                $total = (float)$cart->getOrderTotal(true, Cart::BOTH);
                
                //on recupère les informations du formulaire dumguichet
                 $otp = isset($_POST['otp']) ? $_POST['otp'] : 'null';
                $recipient = $_POST['phoneNumber'];
                $serviceMoney = $_POST['operator'];
                // Récupérer la devise sélectionnée
                $currency = $this->context->currency;
                $currency_code = $currency->iso_code;
                //initialisation des différents tableaux
                //$urlApi = Tools::getHttpHost(true) . __PS_BASE_URI__ . 'modules/mybui/action_url.php';// A decommenter
                $urlApi = 'https://africamax.io/';// A commenter
                //condition en fonction du pays
                //$token = $this->getPays($_POST['country']);
                $token = $_POST['get_token'];
                $reference = $cart->id.'-'.Wpaiement_CC::generateReference();
                $action = array(
                              "successUrl"=> $urlApi, //$urlApi,
                            "errorUrl"=> $urlApi
                          );
                          $mobileMoney = array(
                                  "service" => $serviceMoney,
                                  "reference" => "prestashop-".$reference,
                                  "amount" => (int)$total,
                                  "otpCode"=> $otp,
                                  "recipient"=> $recipient,
                                  "note"=> "paiement sur bui",
                                  "action" => $action
                          );
                          $customer = array(
                                  "firstname"=> Context::getContext()->customer->firstname,
                                  "lastname"=> Context::getContext()->customer->lastname,
                                  "email"=> Context::getContext()->customer->email,
                                  "externalId"=> "",
                                  "phoneNumber"=> $recipient
                          );
      
                //traitement sur prestashop
                try {
                  $dataForm = array(
                                  "paymentMethod"=>"mobile_money",
                                  "mobileMoney" => $mobileMoney,
                                  "customer" => $customer
                              );
                    //traitement
                    $version='v1.0';
                    $wpaiement_cc = new Wpaiement_CC($version);

                    $result = $wpaiement_cc->MakePaymentMobile($dataForm, $token);
                    

                    // Gestion des erreurs
                    if (isset($result['statusCode'])) {
                        
                        if($result['statusCode']==422 || $result['statusCode']==409){
                            $detailsErreur = isset($result['subErrors'][0])?$result['subErrors'][0]: '';
            
                            $this->errors[] = $this->l('une erreur est survenue ! Code : ' .$result['statusCode'] . ' Message :' .$result['message'] . ' Details :' . $detailsErreur. ' Veuillez réessayer!');
                            $this->redirectWithNotifications($this->getCurrentURL());
                
                        }
                    }
                  //Tools::dieObject('resultat:' .$result);
                  elseif (isset($result['payments']['status'])) {
                        $bui_status = $result['payments']['status'];
                        $note ='';
                        //Comparaison du montants payer et du montant initialisé
                        if($result['payments']['fees']['amount'] == $total && $result['payments']['fees']['currency'] == $currency_code)
                        {

                            // Créer un nouvel objet OrderMessage
                           /*  $order_message = new OrderMessage();
                            $order_message->id_order = (int)$cart->id;
                            $order_message->message ='note pour la commande';
                            $order_message->add(); */// Ajouter la note à la commande
                            //Traitement du paiement par WaveCI
                            if ($result['payments']['service'] == 'PAYIN_WAVE_CI'|| $result['payments']['service'] == 'PAYIN_WAVE_SN') {
                                // enregistrement du payments_id et total dans les cookies
                                $this->context->cookie->__set('payments_id', $result['payments']['id']);
                                $this->context->cookie->__set('total_cart', $total);
                                //On redirige vers la page de Wave
                                Tools::redirect($result['payments']['paymentUrl']);
                            }
                            else{
                                //appel fonction mise à jour panier
                                $this->updateStatusCart($bui_status,$cart->id , $total, $this->module->displayName, $this->context->currency->id);
                                Tools::redirect('index.php?controller=history');
                                        
                                    /* case 'succeeded':
                                        $note = 'Paiement succès: Identifiant Bui:'. $result['payments']['id'];
                                        //traitement sur prestahop
                                        $this->module->validateOrder($cart->id, Configuration::get('PS_OS_PAYMENT'), $total, $this->module->displayName, null, array(), $this->context->currency->id, false, false);
                                        Tools::redirect($this->context->link->getPageLink(
                                        'order-confirmation',
                                        Configuration::get('PS_SSL_ENABLED', $this->context->language->id, 'id_cart='.$cart->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.false)));
                                        break; */
                                                                   
                            }
                        }
                        else{
                            $note = 'Erreur survenue: Le montant ou la devise ne correspond pas. Montant:'. $result['payments']['fees']['amount']. ' '. $result['payments']['fees']['currency'];
                            $this->module->validateOrder($cart->id, Configuration::get('PS_OS_ERROR'), $total, $this->module->displayName, null, array(), $this->context->currency->id, false, false);
                            Tools::redirect('index.php?controller=history');
                            }
                        // afficher les notes
                        $this->error[] = $this->l($note);
                        $this->redirectWithNotifications($this->getCurrentURL());
                                                
      
                    }
                  else{
                    $this->error[] = $this->l('Ne correspond à aucun cas');
                    $this->redirectWithNotifications($this->getCurrentURL());
                              }
                } catch (Exception $e) {
                  echo $e->getMessage();
                }
              }

    }
    // Mise à jour de la commande
    public function updateStatusCart($bui_status, $identifiant_cart, $total, $module_name, $context_currency_id) {
        switch ($bui_status)
        {
            case 'failed':
                //$raison = $result['payments']['failureReason'] ? $result['payments']['failureReason'] : 'Inconnu contacter bui';
                //$note = 'Paiement échec. Identifiant Bui:'. $result['payments']['id']. '<br/>Raison:'.$raison.'<br>Recommencer le processus';
                $this->module->validateOrder($identifiant_cart, Configuration::get('PS_OS_ERROR'), $total, $module_name, null, array(), $context_currency_id, false, false);
                break;

            case 'pending' || 'processing':
                // paiement annulé lorsque le delai est depassée
                $this->module->validateOrder($identifiant_cart, Configuration::get('PS_OS_CANCELED'), $total, $module_name, null, array(), $context_currency_id, false, false);
                break;

            case 'succeeded':
                //traitement sur prestahop
                $this->module->validateOrder($identifiant_cart, Configuration::get('PS_OS_PAYMENT'), $total, $module_name, null, array(), $context_currency_id, false, false);
                // Supprimer la clé spécifique du cookie
                Tools::redirect($this->context->link->getPageLink(
                'order-confirmation',
                Configuration::get('PS_SSL_ENABLED', $this->context->language->id, 'id_cart='.$identifiant_cart.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.false)));
                break;

            default:
                $this->module->validateOrder($identifiant_cart, Configuration::get('PS_OS_ERROR'), $total, $module_name, null, array(), $context_currency_id, false, false);
                break;
        }
    }
    /*
    * Fields validation, more in Step 5
    */
    public function getPays($pays) {
        switch ($pays) {
            case 'CI':
                $token = Configuration::get('MY_KEY_CI');
                break;
            case 'CM':
                $token = Configuration::get('MY_KEY_CM');
                break;
            case 'BF':
                $token = Configuration::get('MY_KEY_BF');
                break;
            case 'SN':
                $token = Configuration::get('MY_KEY_SN');
                break;
            default:
                echo 'une erreur est survenue';
                break;
        }

        return $token;
    }
}