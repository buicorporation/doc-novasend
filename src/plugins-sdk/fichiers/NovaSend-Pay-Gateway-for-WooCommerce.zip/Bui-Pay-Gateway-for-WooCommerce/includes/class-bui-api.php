<?php

if (!defined('ABSPATH')) {
    exit;
}

class BUI_API {
    private $api_key;
    private $api_url = 'https://api.buicorporation.io/v1.0/';

    public function __construct($api_key) {
        $this->api_key = $api_key;
    }

    public function create_payment_intent($args) {
        $endpoint = $this->api_url . 'payment-intent';
    
        error_log("BUI API: Requête à l'API");
        error_log("  - URL: " . $endpoint);
        error_log("  - Données: " . json_encode($args));
    
        $response = wp_remote_post($endpoint, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'Accept-Encoding' => 'gzip',
                'Accept-Language' => 'fr'
            ),
            'body' => json_encode($args)
        ));
    
        if (is_wp_error($response)) {
            error_log("BUI API: Erreur WP");
            error_log("  - Message: " . $response->get_error_message());
            return $response;
        }
    
        $body = wp_remote_retrieve_body($response);
        $status_code = wp_remote_retrieve_response_code($response);
    
        error_log("BUI API: Réponse de l'API");
        error_log("  - Code de statut: " . $status_code);
        error_log("  - Corps de la réponse: " . $body);
    
        $decoded_body = json_decode($body, true);
    
        if ($status_code >= 200 && $status_code < 300 && isset($decoded_body['paymentIntent'])) {
            return $decoded_body;
        } else {
            error_log("BUI API: Erreur de réponse");
            error_log("  - Code de statut: " . $status_code);
            error_log("  - Corps de la réponse: " . $body);
            return new WP_Error('bui_api_error', __('Unable to create payment intent', 'bui-pay') . ' - Status: ' . $status_code . ' - Response: ' . $body);
        }
    }
    public function get_payment_intent_status($payment_intent_id) {
        $endpoint = $this->api_url . 'payment-intent/' . $payment_intent_id;

        $response = wp_remote_get($endpoint, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Accept' => 'application/json'
            )
        ));

        if (is_wp_error($response)) {
            return $response;
        }

        return json_decode(wp_remote_retrieve_body($response), true);
    }

    public function check_payment_intent_exists($reference) {
        $endpoint = $this->api_url . 'payment-intent/check/' . urlencode($reference);
    
        $response = wp_remote_get($endpoint, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Accept' => 'application/json'
            )
        ));
    
        if (is_wp_error($response)) {
            return false;
        }
    
        $body = json_decode(wp_remote_retrieve_body($response), true);
    
        return isset($body['exists']) && $body['exists'] === true;
    }
}