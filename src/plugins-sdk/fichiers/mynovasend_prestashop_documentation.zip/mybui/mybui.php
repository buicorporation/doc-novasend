<?php
/**
 *
 * NOTICE OF LICENSE
 *
 * This source file is licensed under the Open Software License version 3.0
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @author    paiement corporation
 * @copyright 2012-2024
 * @license   http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
 * @category  payment
 * @package   paiement_corporation
 * @version   1.0 (rev 1)
 */

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}

class MyBui extends PaymentModule
{
    public function __construct()
    {
        $this->name = 'mybui';
        $this->tab = 'payments_gateways';
        $this->version = '1.0';
        $this->author = 'Bui corporation';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('MyBui');
        $this->description = $this->l('Module de paiement MyBui pour PrestaShop');
        $this->confirmUninstall = $this->l('Êtes-vous sûr de vouloir désinstaller ce module ?');
    }
    public function install()
    {
        if (!parent::install() ||
            !$this->registerHook('paymentOptions') ||
            !$this->registerHook('displayPaymentReturn') ||
           //!$this->registerHook('paymentReturn') ||
            !$this->registerHook('displayAdminOrder')
        ) {
            return false;
        }

        return true;
    }

    public function uninstall()
    {
        if (!parent::uninstall()) {
            return false;
        }

        return true;
    }
    public function getContent()
    {
        $output = null;

        if (Tools::isSubmit('submit'.$this->name)) {
            $key_ci = strval(Tools::getValue('KEY_CI'));
            $key_cm = strval(Tools::getValue('KEY_CM'));
            $key_bf = strval(Tools::getValue('KEY_BF'));
            $key_sn = strval(Tools::getValue('KEY_SN'));

            if (
                empty($key_ci) &&
                empty($key_cm) && empty($key_bf)
            ) {
                $output .= $this->displayError($this->l('Veuillez saisir un token'));
            } else {
                Configuration::updateValue('MY_KEY_CI', $key_ci);
                Configuration::updateValue('MY_KEY_CM', $key_cm);
                Configuration::updateValue('MY_KEY_BF', $key_bf);
                Configuration::updateValue('MY_KEY_SN', $key_sn);
                $output .= $this->displayConfirmation($this->l('Settings updated'));
            }
        }

        return $output.$this->displayForm();
    }
    public function displayForm()
    {
        // Get default language
        $default_lang = (int)Configuration::get('PS_LANG_DEFAULT');

        // Init Fields form array
        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('Settings'),
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('Token Côte d\'Ivoire'),
                    'name' => 'KEY_CI',
                    'size' => 20,
                    'required' => false
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Token Cameroun'),
                    'name' => 'KEY_CM',
                    'size' => 20,
                    'required' => false
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Token Burkina Faso'),
                    'name' => 'KEY_BF',
                    'size' => 20,
                    'required' => false
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Token Senegal'),
                    'name' => 'KEY_SN',
                    'size' => 20,
                    'required' => false
                ),
            ),
            'submit' => array(
                'title' => $this->l('Save'),
                'class' => 'btn btn-default pull-right'
            )
        );

        $helper = new HelperForm();

        // Module, token and currentIndex
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

        // Language
        $helper->default_form_language = $default_lang;
        $helper->allow_employee_form_lang = $default_lang;

        // Title and toolbar
        $helper->title = $this->displayName;
        $helper->show_toolbar = true;
        $helper->toolbar_scroll = true;
        $helper->submit_action = 'submit'.$this->name;

        // Load current value
        $helper->fields_value['KEY_CI'] = Configuration::get('MY_KEY_CI');
        $helper->fields_value['KEY_CM'] = Configuration::get('MY_KEY_CM');
        $helper->fields_value['KEY_BF'] = Configuration::get('MY_KEY_BF');
        $helper->fields_value['KEY_SN'] = Configuration::get('MY_KEY_SN');

        return $helper->generateForm($fields_form);
    }
    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        $payment_option = new PaymentOption();
        $payment_option->setCallToActionText($this->displayName)
                       ->setAction($this->context->link->getModuleLink($this->name, 'validation', array(), true))
                       ->setLogo(Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/logo.png'))
                       ->setModuleName($this->name)
                       ->setAdditionalInformation('Paiement par mobileMoney et Wallet');

        return [$payment_option];
    }
    public function hookPayment($params)
    {
        if (!$this->active) {
            return;
        }

        $this->smarty->assign(array(
            'this_path' => $this->_path,
            'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->name.'/'
        ));

        return $this->display(__FILE__, '/views/templates/front/payment.tpl');
    }

    public function hookPaymentReturn($params)
    {
        if (!$this->active) {
            return;
        }

        return $this->display(__DIR__, '/views/templates/front/payment_return.tpl');
    }
}