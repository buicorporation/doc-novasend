<?php
/**
 * CinetPay
 *
 * LICENSE
 *
 * This source file is subject to the MIT License that is bundled
 * with this package in the file LICENSE.
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to support@wpaiement.com so we can send you a copy immediately.
 * @category wpaiement
 * @package  wpaiement
 * @license  MIT
 * @version
 */
 //use GuzzleHttp\Client;

class Wpaiement_CC
{
    public $BASE_URL = 'https://api.buicorporation.io/';
    public $api_key = null;
    public $reference = null;
    public $note = null;
    
    public function __construct($version='v1.0', $params = null) {
        $this->BASE_URL= 'https://api.buicorporation.io/'.$version;
    }
    //Get Service available
    public function getService($apikey) {
        $this->api_key = $apikey;
        $flux_json = $this->callWsMethod(null,$this->BASE_URL.'/services/payin/list', 'GET', $apikey );

        $result = json_decode($flux_json, true);
        
        //gestion des mauvaises authentification
        if (isset($result['statusCode']) && $result['statusCode']== 401) {
            # code...
            return [
               'statusCode'=>401,
               'message'=>"Erreur d'authentification du token, veuillez contacter l'administrateur"
            ];
        }

        return [
            'status'=>200,
            'data'=>$result['services']
         ];
        
    }

    // make payment
    public function MakePaymentMobile($params, $apikey) {

        $flux_json = $this->callWsMethod($params,$this->BASE_URL.'/payments', 'POST', $apikey );

        $result = json_decode($flux_json, true);

        //Gestion transaction en attente

        if(isset($result['payments']['status'])) {
        
          if(($result['payments']['service']=='PAYIN_WAVE_CI' || $result['payments']['service']=='PAYIN_WAVE_SN') && $result['payments']['status'] == 'pending') {
            $result = $this->CheckPaymentMobile($result['payments']['id'] , $apikey, 2, 3);
          }
          elseif ($result['payments']['status'] == 'pending') {
            $result = $this->CheckPaymentMobile($result['payments']['id'] , $apikey, 3, 15);
          }
        }
        return $result;
    }

    // check status
    public function CheckPaymentMobile($paymentId, $apikey, $nbre_retry, $latence)
    {
        // pour relancer le checking
        $retries = 0;

        while ($retries < $nbre_retry) {
            // Verifier le statut
          $check_json = $this->callWsMethod(null,$this->BASE_URL.'/payments/'.$paymentId , 'GET', $apikey );

          $check_result = json_decode($check_json, true);

          if($check_result['payments']['status'] == 'pending' || $check_result['payments']['status'] == 'processing'){
            // Le statut est en attente, attendre 10 secondes
            sleep($latence);
            $retries++;
          }
          else {
            // Le statut n'est plus en attente, terminer la boucle
            break;
          }
        }
      return $check_result;

    }
        //send data with Guzzle
        public function callRequestApi($url, $api_key) {
            try {
                //code...
                $client = new Client();
                $res = $client->request('GET', $url, [
                    'headers' => [ 'Authorization' => 'Bearer ' . $api_key ],
                ]);
                if($res->getStatusCode() != "200")
                {
                    if($res->getStatusCode() == "401") {$reponse = "api key incorrect";}

                    $reponse = "Une autre erreur est survenu veuillez contacter le service";
                }
                elseif ($res->getStatusCode() == "200") {
                    $reponse = $res->getBody();
                }

                return $reponse;

            } catch (Exception $e) {
                throw new Exception($e);
            }
            
        }
    //send datas
    public function callWsMethod($params, $url, $method, $api_key)
    {
    
        if (function_exists('curl_version')) {
            try {
                $authorization = "Authorization: Bearer ".$api_key;

                $curl = curl_init();
                
                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 45,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => $method,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_POSTFIELDS => json_encode($params),
                    CURLOPT_HTTPHEADER => array(
                        "content-type:application/json",
                        $authorization
                    ),
                ));
                $response = curl_exec($curl);
                $err = curl_error($curl);
                curl_close($curl);
                if ($err) {
                    throw new Exception("Error :" . $err);
                } else {
                    return $response;
                }
            } catch (Exception $e) {
                throw new Exception($e);
            }
        }  else {
            throw new Exception("Vous devez activer curl ou allow_url_fopen pour utiliser ");
        }
    }

    public static function generateReference() //ajout de la methode static pour ceux qui utilise une version < 7.4
    {
      $timestamp = time();
      $parts = explode(' ', microtime());
      $id = ($timestamp + $parts[0] - strtotime('today 00:00')) * 10;
      $id = sprintf('%06d', $id) . mt_rand(100, 9999);

      return $id;
    }
}
