<?php
if (!defined('ABSPATH')) {
    exit;
}

class BUI_Webhook_Handler {
    public static function handle_webhook() {
        // Récupérer les données du webhook
        $payload = file_get_contents('php://input');
        $data = json_decode($payload, true);

        if (!$data) {
            status_header(400);
            exit('Invalid webhook payload');
        }

        // Vérifier la signature du webhook
        $signature = $_SERVER['HTTP_X_BUICORPORATION_SIGNATURE'] ?? '';

        // Récupérer le secret du webhook
        $webhook_secret = get_option('woocommerce_bui_pay_settings')['webhook_secret'] ?? '';

        // Calculer la signature en utilisant HMAC SHA-256
        $computed_signature = hash_hmac('sha256', $payload, $webhook_secret);

        // Comparer les signatures
        if (!hash_equals($computed_signature, $signature)) {
            status_header(403);
            exit('Invalid webhook signature');
        }

        // Vérification du statut du paiement
        $payment_status = $data['payments']['status'] ?? '';

        if ($payment_status === 'succeeded') {
            self::process_successful_payment($data['payments']);
        } elseif ($payment_status === 'failed') {
            self::process_failed_payment($data['payments']);
        } else {
            status_header(400);
            exit('Unknown status');
        }

        status_header(200);
        exit('Webhook processed');
    }

    private static function process_successful_payment($payment_data) {
        // Extraire l'ID de la commande à partir de la référence
        $reference = $payment_data['reference'];
        $order_id = explode('-', $reference)[0]; // Supposons que le numéro de commande WooCommerce est avant le tiret
    
        $order = wc_get_order($order_id);
        if (!$order) {
            error_log('BUI Payment: Unable to find order ' . $order_id);
            return;
        }
    
        // Marquer la commande comme payée
        $order->payment_complete($payment_data['id']);
        $order->add_order_note(__('Payment completed via BUI Payment', 'bui-payment-gateway'));
    }
    
    private static function process_failed_payment($payment_data) {
        // Extraire l'ID de la commande à partir de la référence
        $reference = $payment_data['reference'];
        $order_id = explode('-', $reference)[0]; // Supposons que le numéro de commande WooCommerce est avant le tiret
    
        $order = wc_get_order($order_id);
        if (!$order) {
            error_log('BUI Payment: Unable to find order ' . $order_id);
            return;
        }
    
        // Marquer la commande comme échouée
        $order->update_status('failed', __('Payment failed via BUI Payment: ' . $payment_data['failureReason'], 'bui-payment-gateway'));
        $order->add_order_note(__('Payment failed via BUI Payment: ' . $payment_data['failureReason'], 'bui-payment-gateway'));
    }
    
}
