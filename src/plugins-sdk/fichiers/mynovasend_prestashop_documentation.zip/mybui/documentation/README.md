# Module de Paiement MyBui pour PrestaShop

## Introduction

Le module de paiement MyBui vous permet d'intégrer la passerelle de paiement BuiCorporation à votre boutique PrestaShop. Ce module offre une expérience de paiement fluide à vos clients, leur permettant de payer via MyBui directement depuis votre boutique en ligne.

## Fonctionnalités

- **Intégration Facile** : Configurez rapidement et facilement la passerelle de paiement MyBui.
- **Transactions Sécurisées** : Tous les paiements sont traités de manière sécurisée via la passerelle MyBui.

## Prérequis

Avant de procéder à l’intégration du plugin de paiement, veuillez-vous assurer:
 - De Récupérer votre Token dans votre compte marchand
 - La devise de votre boutique correspond au token
 - Le pays sur le formulaire de commande correspond au pays du token

## Installation

1. **Télécharger le Module** : Téléchargez le package du module de paiement MyBui.
2. **Uploader le Module** : 
    - Connectez-vous à votre back-office PrestaShop.
    - Allez dans `Modules` > `Gestion des modules`.
    - Cliquez sur `Ajouter un nouveau module`.
    - Sélectionnez le fichier zip du module MyBui et uploadez-le.
3. **Installer le Module** :
    - Une fois uploadé, cliquez sur `Installer` pour installer le module de paiement MyBui.
4. **Configurer le Module** :
    - Après l'installation, cliquez sur `Configurer`.
    - Entrez votre token
    - Sauvegardez la configuration.

## Configuration

### Identifiants API

Pour configurer le module, vous aurez besoin de vos identifiants API MyBui :

- **token** : C'est la clé fournie par BuiCorporation pour l'authentification.

1. Allez dans `Modules` > `Gestion des modules`.
2. Trouvez le module de paiement MyBui et cliquez sur `Configurer`.
3. Entrez votre token
4. Cliquez sur `Sauvegarder`.

### Méthodes de Paiement

La méthode de paiement MyBui apparaîtra automatiquement sur la page de commande une fois le module configuré.

## Utilisation

### Traitement des Paiements

1. Lorsqu'un client sélectionne MyBui comme méthode de paiement lors du passage en caisse, il sera redirigé vers le formulaire de paiement BuiCorporation.
2. Après avoir complété le paiement, il sera redirigé vers l'historique avec une confirmation de sa commande.

### Gestion des Commandes

- Vous pouvez voir et gérer les commandes payées via MyBui dans le back-office PrestaShop sous `Commandes`.
- Le statut de la commande sera automatiquement mis à jour en fonction de la réponse de MyBui.

## Dépannage

### Problèmes Courants

- **Token** : Vérifiez que vous avez bien saisi les identifiants API corrects.
- **Paiement Non Affiché** : Assurez-vous que le module est bien installé et configuré. Vérifiez que la méthode de paiement MyBui est active dans les paramètres de paiement.

### Debugging

Pour activer le mode de débogage :

1. Ouvrez le fichier `config/defines.inc.php`.
2. Modifiez la ligne suivante :
    
    ```php
    define('_PS_MODE_DEV_', true);
    ```

Consultez les logs pour toute erreur ou problème lié au module MyBui.

## Désinstallation

Pour désinstaller le module de paiement MyBui :

1. Allez dans `Modules` > `Gestion des modules`.
2. Trouvez le module de paiement MyBui.
3. Cliquez sur `Désinstaller`.

Cela supprimera la méthode de paiement MyBui de votre boutique.

## Support

Pour le support, veuillez nous contacter via :

- **Site Web** : [Support Officiel BuiCorporation](https://buicorporation.com/)
- **Documentation** : [Documentation BuiCorporation](https://docs.buicorporation.io/starting.html)

## Journal des Modifications

### Version 1.0
- Première version avec les fonctionnalités de base pour le traitement des paiements.
- Affichage dans la page de commande
- Ce module vérifie si le pays du client appartient à l'api supportée

---
