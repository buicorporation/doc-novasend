<?php
/*
Plugin Name: BUI Pay for WooCommerce
Plugin URI: https://buicorporation.io
Description: Custom payment gateway integration for BUI Corporation
Version: 1.0.0
Author: buicorporation
Author URI: https://buicorporation.io
Text Domain: bui-pay
Domain Path: /languages
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Check if WooCommerce is active
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    return;
}

// Hook to initialize the payment gateway
add_filter('woocommerce_payment_gateways', 'bui_pay_add_gateway_class');
function bui_pay_add_gateway_class($gateways) {
    $gateways[] = 'WC_BUI_Pay_Gateway';
    return $gateways;
}

// Initialize the plugin
add_action('plugins_loaded', 'bui_pay_init', 11);
function bui_pay_init() {
    // Load plugin textdomain
    load_plugin_textdomain('bui-pay', false, dirname(plugin_basename(__FILE__)) . '/languages/');

    // Include the gateway class
    require_once plugin_dir_path(__FILE__) . 'includes/class-bui-pay-gateway.php';
    require_once plugin_dir_path(__FILE__) . 'includes/class-bui-api.php';
}