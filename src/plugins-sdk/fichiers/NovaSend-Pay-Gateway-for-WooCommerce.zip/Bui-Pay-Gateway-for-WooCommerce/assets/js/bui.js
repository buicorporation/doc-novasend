const successCallback = function(data) {
    const checkoutForm = jQuery('form.woocommerce-checkout');
    checkoutForm.find('#bui_token').val(data.token);
    checkoutForm.off('checkout_place_order', tokenRequest);
    checkoutForm.submit();
}

const errorCallback = function(data) {
    console.log(data);
}

const tokenRequest = function() {
    // Fonction pour obtenir le token
    return false;
}

jQuery(function($) {
    const checkoutForm = $('form.woocommerce-checkout');
    checkoutForm.on('checkout_place_order', tokenRequest);
});