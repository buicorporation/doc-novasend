{extends file="page.tpl"}

{block name='content'}
    {if $error_message!=null}
        <div class="alert alert-danger">
            {$error_message}
        </div>
        {else}
          <section id="content" class="container mt-2 row" style="margin: auto;">
            <div class="col-lg-6 mx-auto">
              <h3>
                  {l s='Procéder au paiement' mod='mybui'}
              </h3>
              {*
                - Ajouter un recap du montant et la devise
              *}
              <form method="POST" id="form-one" class="page-content card card-block">
                  
                  <div class="form-group">
                   <label for="countrySelect">{l s='Sélectionnez le pays :' mod='mybui'}</label>
                    <!-- operateur-->
                    <select class="form-control" name="operator" id="selectOperateur" aria-label="Small select example">
                            <option disabled selected>{l s='--Sélectionnez l\'opérateur --' mod='mybui'}</option>
                            {foreach from=$operateurs item=operateur}
                                <option value="{$operateur.serviceId|escape:'htmlall':'UTF-8'}">{$operateur.name|escape:'htmlall':'UTF-8'}</option>
                            {/foreach}
                    </select>
                  </div>
                 
                  {* continuer button *}
                  <div class="form-group">
                    <input type="submit" class="btn btn-primary btn-block shadow-sm" name="continuer" value="{l s='Continuer' mod='mybui'}">
                  </div>
                
              </form>
            </div>
          </section>
      {/if}
{/block}