{extends file="page.tpl"}

{block name='content'}
  {if $error_message!=null}
    <div class="alert alert-danger">
        {$error_message}
    </div>
    {else}
      <section id="content" class="container mt-2 row" style="margin: auto;">
        <div class="col-lg-6 mx-auto">
          <h3>
              {l s='Confirmer le paiement' mod='mybui'}
          </h3>
          {*
            - Ajouter un recap du montant et la devise
          *}
          <form method="POST" id="payment-form" class="page-content card card-block">
            {if isset($selected_operator)}
              {foreach from=$operateurs item=operateur}
                {if $operateur.serviceId == $selected_operator}
                  <input type="hidden" value="{$get_token}" name="get_token">
                  <input type="hidden" value="{$selected_operator}" name="operator">
                  <div class="form-group">
                    <h3>
                      Montant à payer:<span> {$montant|escape:'htmlall':'UTF-8'} {$currency_code|escape:'htmlall':'UTF-8'}</span>
                    </h3>
                  </div>
                  
                  <div class="form-group"> 
                    <label for="cardNumber">
                      {l s='Entrez le numéro avec l\'indicatif du pays' mod='mybui'}
                    </label>
                    <div class="input-group">
                        <input type="text" name="phoneNumber" min="{$operateur.extras.nsnLength|escape:'htmlall':'UTF-8'}" max="{$operateur.extras.nsnLength|escape:'htmlall':'UTF-8'}" 
                              placeholder="{$operateur.extras.e164Mask|escape:'htmlall':'UTF-8'}" class="form-control" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="">
                     {$operateur.extras.instruction|escape:'htmlall':'UTF-8'}
                    </label>
                  </div>
                  {if $operateur.serviceId == 'PAYIN_ORANGE_CI' || $operateur.serviceId == 'PAYIN_ORANGE_BF' || $operateur.serviceId == 'PAYIN_ORANGE_SN'}
                     <div class="form-group">   
                      <input type="number" name="otp" placeholder="saisir le code otp" class="form-control ">
                    </div>
                  {/if}
                  {* Submit button *}
                  <div class="form-group">
                    <input type="submit" class="btn btn-primary btn-block shadow-sm" name="valider" value="{l s='Valider paiement' mod='mybui'}">
                  </div>
                 {if $operateur.serviceId == 'PAYIN_WAVE_CI' || $operateur.serviceId == 'PAYIN_WAVE_SN'}          
                    {* button check for wave*}
                    <div class="form-group">
                      <input type="submit" class="btn btn-secondary btn-block shadow-sm" name="check" value="{l s='Vérifier paiement wave' mod='mybui'}">
                    </div>
                 {/if}
                {/if}
              {/foreach}
            {/if}
          </form>
        </div>
      </section>
  {/if}
{/block}
{block name='notifications'}
  {include file='_partials/notifications.tpl'}
{/block}